"""Fase 8, secao 7 -- SyncCatalogUseCase.

Fakes de CatalogIndex e CatalogSyncStatusRepository -- confirma que
record() e' sempre chamado com o SyncResult (sucesso OU falha) e um
timestamp, nunca so' nos casos de sucesso (e' justamente a falha que a
tela "Catalog" precisa poder mostrar, ver CatalogSyncStatusRepository).
"""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from auditor.application.use_cases.sync_catalog import SyncCatalogUseCase
from auditor.infrastructure.schema_catalog.catalog_index import SyncResult

_NOW = datetime(2026, 9, 6, tzinfo=timezone.utc)


class _FakeCatalogIndex:
    def __init__(self, result: SyncResult):
        self._result = result
        self.sync_called = False

    def sync(self) -> SyncResult:
        self.sync_called = True
        return self._result


class _FakeStatusRepository:
    def __init__(self):
        self.recorded: list[tuple[SyncResult, datetime]] = []

    async def record(self, result: SyncResult, attempted_at: datetime) -> None:
        self.recorded.append((result, attempted_at))


class TestSyncCatalogUseCase:
    @pytest.mark.asyncio
    async def test_a_successful_sync_is_recorded_with_the_result_and_a_timestamp(self):
        result = SyncResult(success=True, models_count=42, reason=None)
        catalog_index = _FakeCatalogIndex(result)
        status_repository = _FakeStatusRepository()
        use_case = SyncCatalogUseCase(catalog_index, status_repository, clock=lambda: _NOW)

        returned = await use_case.execute()

        assert returned is result
        assert catalog_index.sync_called is True
        assert status_repository.recorded == [(result, _NOW)]

    @pytest.mark.asyncio
    async def test_a_failed_sync_is_also_recorded_never_silently_dropped(self):
        result = SyncResult(success=False, models_count=None, reason="Hugging Face Hub unreachable (403)")
        catalog_index = _FakeCatalogIndex(result)
        status_repository = _FakeStatusRepository()
        use_case = SyncCatalogUseCase(catalog_index, status_repository, clock=lambda: _NOW)

        returned = await use_case.execute()

        assert returned is result
        assert status_repository.recorded == [(result, _NOW)]
