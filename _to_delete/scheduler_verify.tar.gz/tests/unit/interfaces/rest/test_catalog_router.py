"""Fase 8, secao 7 -- GET /catalog. Ver .cursor/specs/fase8.spec.md.

Mesmo padrao ASGITransport + dependency_overrides de test_audits_router.py.
Este router nao depende de tenant (o catalogo e' global), entao os testes
aqui nunca enviam _TENANT_HEADERS.
"""

from __future__ import annotations

from datetime import datetime, timezone

import httpx
import pytest

from auditor.infrastructure.config.container import get_catalog_sync_status_repository
from auditor.infrastructure.schema_catalog.catalog_sync_status_repository import (
    CatalogSyncStatus,
)
from auditor.interfaces.rest.app import create_app


class _FakeCatalogSyncStatusRepository:
    def __init__(self, status: CatalogSyncStatus | None = None):
        self._status = status

    async def get(self) -> CatalogSyncStatus | None:
        return self._status


@pytest.fixture
def fake_repository() -> _FakeCatalogSyncStatusRepository:
    return _FakeCatalogSyncStatusRepository()


@pytest.fixture
def app_and_repository(fake_repository):
    app = create_app()
    app.dependency_overrides[get_catalog_sync_status_repository] = lambda: fake_repository
    return app, fake_repository


@pytest.fixture
async def client(app_and_repository):
    app, _ = app_and_repository
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


class TestGetCatalogStatus:
    @pytest.mark.asyncio
    async def test_no_sync_ever_attempted_returns_all_none_fields(self, client):
        response = await client.get("/catalog")

        assert response.status_code == 200
        assert response.json() == {
            "last_synced_at": None,
            "last_sync_successful": None,
            "last_sync_error": None,
            "models_count": None,
        }

    @pytest.mark.asyncio
    async def test_a_successful_sync_from_days_ago_is_shown(self, client, fake_repository):
        synced_at = datetime(2026, 9, 1, tzinfo=timezone.utc)
        fake_repository._status = CatalogSyncStatus(
            last_synced_at=synced_at,
            last_sync_successful=True,
            last_sync_error=None,
            models_count=42,
        )

        response = await client.get("/catalog")

        assert response.status_code == 200
        body = response.json()
        assert body["last_sync_successful"] is True
        assert body["models_count"] == 42
        assert body["last_synced_at"].startswith("2026-09-01")

    @pytest.mark.asyncio
    async def test_a_failed_attempt_after_a_prior_success_still_shows_the_last_successful_sync(
        self, client, fake_repository
    ):
        """CatalogSyncStatusRepository.record() nunca sobrescreve o ultimo
        sucesso com uma falha (ver seu docstring) -- este teste confirma que
        o efeito e' visivel na borda HTTP: o catalogo local (da ultima
        sincronizacao boa) continua sendo mostrado, junto com o aviso de
        que a tentativa mais recente falhou."""
        last_good = datetime(2026, 8, 20, tzinfo=timezone.utc)
        fake_repository._status = CatalogSyncStatus(
            last_synced_at=last_good,
            last_sync_successful=False,
            last_sync_error="Hugging Face Hub unreachable (403)",
            models_count=42,
        )

        response = await client.get("/catalog")

        assert response.status_code == 200
        body = response.json()
        assert body["last_sync_successful"] is False
        assert body["last_sync_error"] == "Hugging Face Hub unreachable (403)"
        # o catalogo local mostrado e' o da ultima sincronizacao BOA, nunca
        # None so' porque a tentativa mais recente falhou.
        assert body["models_count"] == 42
        assert body["last_synced_at"].startswith("2026-08-20")
