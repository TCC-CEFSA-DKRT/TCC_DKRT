"""GET /catalog. Ver .cursor/specs/fase8.spec.md, secao 7.

Global, nao por tenant (o catalogo de Smart Data Models nao e' um dado do
tenant) — unico router desta API sem `Depends(get_tenant)`.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends

from auditor.infrastructure.config.container import get_catalog_sync_status_repository
from auditor.infrastructure.schema_catalog.catalog_sync_status_repository import (
    CatalogSyncStatusRepository,
)
from auditor.interfaces.rest.schemas import CatalogStatusResponse

router = APIRouter(prefix="/catalog", tags=["catalog"])


@router.get("", response_model=CatalogStatusResponse)
async def get_catalog_status(
    repository: CatalogSyncStatusRepository = Depends(get_catalog_sync_status_repository),
) -> CatalogStatusResponse:
    status = await repository.get()
    if status is None:
        # Nunca sincronizado ainda — estado valido e explicito, nunca 404
        # (o catalogo em si existe e funciona via CatalogIndex.resolve(),
        # so' o HISTORICO de sincronizacao esta vazio).
        return CatalogStatusResponse(
            last_synced_at=None,
            last_sync_successful=None,
            last_sync_error=None,
            models_count=None,
        )
    return CatalogStatusResponse(
        last_synced_at=status.last_synced_at,
        last_sync_successful=status.last_sync_successful,
        last_sync_error=status.last_sync_error,
        models_count=status.models_count,
    )
