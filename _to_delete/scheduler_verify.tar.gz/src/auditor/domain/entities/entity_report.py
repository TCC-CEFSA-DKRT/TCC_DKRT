"""EntityReport entity — ver .cursor/specs/fase1.spec.md, secao 2.2."""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum

from auditor.domain.entities.recommendation import Recommendation
from auditor.domain.entities.violation import Violation
from auditor.domain.errors import InconsistentEntityReportError
from auditor.domain.value_objects.conformance_status import ConformanceStatus
from auditor.domain.value_objects.data_model_ref import DataModelRef
from auditor.domain.value_objects.entity_type import EntityType


class SchemaSource(str, Enum):
    LIVE = "live"
    CACHE = "cache"


@dataclass(frozen=True)
class SchemaOrigin:
    """De onde veio o schema usado nesta analise — honestidade metodologica:
    um relatorio vindo de schema em cache nunca fica indistinguivel de um
    confirmado ao vivo."""

    source: SchemaSource
    fetched_at: datetime


@dataclass
class EntityReport:
    """Resultado de conformidade de uma unica entidade dentro de um AuditRun."""

    entity_id: str
    entity_type: EntityType
    data_model: DataModelRef | None
    status: ConformanceStatus
    violations: list[Violation]
    recommendations: list[Recommendation] = field(default_factory=list)
    schema_origin: SchemaOrigin | None = None
    semantic_analysis_skipped: bool = True
    analyzed_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def __post_init__(self) -> None:
        if self.data_model is None and self.status != ConformanceStatus.NO_MODEL_FOUND:
            raise InconsistentEntityReportError(
                "EntityReport.data_model e None mas status nao e NO_MODEL_FOUND."
            )
        if self.data_model is not None and self.status == ConformanceStatus.NO_MODEL_FOUND:
            raise InconsistentEntityReportError(
                "EntityReport.status e NO_MODEL_FOUND mas data_model esta presente."
            )
        # NO_MODEL_FOUND e SCHEMA_UNAVAILABLE (ajuste retroativo da Fase 2,
        # .cursor/specs/fase2.spec.md secao 4) nunca sao derivados de
        # violacoes — os dois so fazem sentido quando o Nivel 1 nem chegou a
        # rodar (sem schema, nao ha o que validar).
        if self.status in (ConformanceStatus.NO_MODEL_FOUND, ConformanceStatus.SCHEMA_UNAVAILABLE):
            return
        expected_status = ConformanceStatus.derive(self.violations, model_found=True)
        if expected_status != self.status:
            raise InconsistentEntityReportError(
                f"EntityReport.status ({self.status}) inconsistente com suas "
                f"violacoes (derivacao indica {expected_status})."
            )
