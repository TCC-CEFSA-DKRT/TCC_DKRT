"""SyncCatalogUseCase — orquestra CatalogIndex.sync() (Fase 2) +
CatalogSyncStatusRepository.record() (Fase 8, secao 7).

Administrativo por design: nenhum endpoint HTTP dispara isto (mesmo
padrao ja' aceito para a sincronizacao do catalogo na Fase 2 e do corpus
RAG na Fase 6, .cursor/specs/fase6.spec.md secao 8) — a Fase 8 so exige
que o RESULTADO de uma sincronizacao fique visivel via `GET /catalog`.

O gatilho administrativo e' o comando `audit catalog sync`
(interfaces/cli/main.py) -- adicionado depois da Fase 8 ao constatar que,
sem ele, nao havia NENHUM jeito de popular o que `GET /catalog` mostra
fora dos testes unitarios (a tela Catalog do frontend sempre mostrava
"nunca sincronizado").
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Callable

from auditor.infrastructure.schema_catalog.catalog_index import CatalogIndex, SyncResult
from auditor.infrastructure.schema_catalog.catalog_sync_status_repository import (
    CatalogSyncStatusRepository,
)


class SyncCatalogUseCase:
    def __init__(
        self,
        catalog_index: CatalogIndex,
        status_repository: CatalogSyncStatusRepository,
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        self._catalog_index = catalog_index
        self._status_repository = status_repository
        self._clock = clock or (lambda: datetime.now(timezone.utc))

    async def execute(self) -> SyncResult:
        # CatalogIndex.sync() e' sincrono de proposito (Fase 2: a
        # biblioteca pysmartdatamodels nao expoe uma API assincrona) —
        # nao convertido para thread aqui porque esta fase nao expoe isto
        # via HTTP (sem risco de bloquear o event loop de uma requisicao).
        result = self._catalog_index.sync()
        await self._status_repository.record(result, attempted_at=self._clock())
        return result
