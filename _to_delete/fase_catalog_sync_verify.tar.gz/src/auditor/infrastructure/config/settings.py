"""Settings — pydantic-settings lendo de variaveis de ambiente/.env. Ver
docs/plano_refatoracao_v3.md, Parte III, 2.2
(infrastructure/config/settings.py) e .env.example.
"""

from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    fiware_broker_url: str = "http://localhost:1026"
    fiware_service: str = "openiot"
    fiware_service_path: str = "/"
    database_url: str = "postgresql+asyncpg://auditor:auditor@localhost:5433/auditor"

    # Fase 7 (.cursor/specs/fase7.spec.md, secao 5) -- Ollama local/dev.
    ollama_base_url: str = "http://localhost:11434"
    ollama_model: str = "qwen2.5:7b-instruct"

    # Fase 8 (.cursor/specs/fase8.spec.md, secao 9): o frontend Angular
    # roda via `ng serve` (porta padrao 4200) contra esta API local -- sem
    # CORS liberado para essa origem, todo fetch do navegador falharia
    # antes mesmo de chegar num router. Lista separada por virgula via env
    # (CORS_ALLOWED_ORIGINS) para producao poder restringir/trocar sem
    # mudar codigo.
    cors_allowed_origins: str = "http://localhost:4200"

    @property
    def cors_allowed_origins_list(self) -> list[str]:
        return [origin.strip() for origin in self.cors_allowed_origins.split(",") if origin.strip()]
